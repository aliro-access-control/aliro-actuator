#
# Copyright 2024 NXP
# SPDX-License-Identifier: Apache-2.0
#

import time

from ucitool.base_uci.cmds import Cmds, get_uci, APP_CFG, DEVICE_CFG, PLATFORM, BOARD_VARIANT, SESSION_TYPE, TEST_CFG, \
    CALIB_TYPE, VENDOR_APP_CFG
from ucitool.base_uci.uci import ConfigSetBuilder, ConfigGetBuilder, UciHost, UwbDeviceCfg  # noqa


def __calculate_time(func):
    """
    Decorator to find a UCI run time.
    """

    def run(*args, **kwargs):
        t1 = time.time()
        ret = func(*args, **kwargs)
        print('Time taken to execute {} is {} secs'.format(func.__name__, time.time() - t1))
        return ret

    return run


def session_get_count(dev):
    """
        UCI cmd to retrieve the session count
        """
    uci = get_uci(Cmds.SESSION_GET_COUNT)
    return dev.exec_uci(uci)


def get_dev_info(dev):
    """
    UCI cmd to retrieve the
    device information like (UCI version and other vendor specific info)
    """
    uci = get_uci(Cmds.GET_DEV_INFO)
    return dev.exec_uci(uci)


def get_caps(dev):
    """
    DH shall use CORE_GET_CAPS_INFO_CMD command to get the capability of the UWBD.
    The capability information is vendor specific and DH shall use capability information to communicate with UWBD.
    """
    uci = get_uci(Cmds.GET_CAPS_INFO)
    return dev.exec_uci(uci)


def set_device_config(dev, config=None, value=None):
    """
    UCI to  set the device configuration parameters.
    """
    uci = get_uci(Cmds.SET_CONFIG)
    c_builder = ConfigSetBuilder()
    if config and value:
        uci.PARAMETERS = 1
        c_builder.add_attr(config, value)
    else:
        uci.PARAMETERS = 1
        c_builder.add_attr(DEVICE_CFG.LOW_POWER_MODE, DEVICE_CFG.LOW_POWER_MODE.DISABLED)
    uci.DEVICE_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_device_config(dev, config=DEVICE_CFG.DEVICE_STATUS):
    """
    UCI to get the current device configuration
    """
    uci = get_uci(Cmds.GET_CONFIG)
    c_builder = ConfigGetBuilder()
    uci.PARAMETERS = 1
    c_builder.add_attr(config)
    uci.DEVICE_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def device_suspend(dev):
    """
    UCI to put device into suspend
    """
    return dev.exec_uci(get_uci(Cmds.DEV_SUSPEND))


def device_reset(dev):
    """
    UCI to reset device
    """
    uci = get_uci(Cmds.DEVICE_RESET)
    uci.RESET_CONFIG = 0
    return dev.exec_uci(uci)


def session_init(dev, session_id=0x11111111, session_type=SESSION_TYPE.SESSION_CCC):
    """
    UCI to create the new UWB session
    :param : session ID
             session_type: SESSION_CCC
    """
    uci = get_uci(Cmds.SESSION_INIT)
    uci.SESSION_ID = session_id
    uci.SESSION_TYPE = session_type
    return dev.exec_uci(uci)


def session_de_init(dev, session_id=0x00000000):
    """
    UCI to de-initialize the session
    param : session ID
    """
    uci = get_uci(Cmds.SESSION_DEINIT)
    uci.SESSION_ID = session_id
    return dev.exec_uci(uci)


def set_app_config(dev, session_id=0x00000000, device_role=APP_CFG.DEVICE_ROLE.INITIATOR,
                   device_type=APP_CFG.DEVICE_TYPE.CONTROLLER,
                   src_addr=APP_CFG.SRC_MAC_ADDRESS.MASTER_ADDR,
                   dst_addr=APP_CFG.DST_MAC_ADDRESS_LIST.ANCHOR_ADDR,
                   rng_type=APP_CFG.RANGING_ROUND_USAGE.DS_TWR,
                   channel=APP_CFG.CHANNEL_ID.CH_5,
                   ppdu_cfg=APP_CFG.RFRAME_CONFIG.SP3,
                   multi_node_mode=APP_CFG.MULTI_NODE_MODE.SINGLE_DEVICE_TO_SINGLE_DEVICE,
                   no_of_anchors=APP_CFG.NUMBER_OF_CONTROLEES.SINGLE_ANCHOR,
                   tx_antenna=None,
                   rx_antenna=None,
                   ri=APP_CFG.RANGING_DURATION.DEFAULT_RANGING):
    """
    UCI to set application configuration parameters
    :param:device_role:CONTROLLER, CONTROLEE
           device_type:INITIATOR,RESPONDER
           src_addr:SRC_MAC_ADDRESS
           dst_addr:DST_MAC_ADDRESS
           rng_type:ONE_WAY,DS_TWR,SS_TWR
           ppdu_cfg: NO_STS,STS_FOLLOWS_SFD,STS_FOLLOWS_PSDU,STS_FOLLOWS_SFD_NO_PPDU
           power_idx: 0-127
    """
    uci = get_uci(Cmds.SET_APP_CONFIG)
    uci.SESSION_ID = session_id
    c_builder = ConfigSetBuilder()
    if hasattr(APP_CFG, "DEVICE_ROLE"):
        c_builder.add_attr(APP_CFG.DEVICE_ROLE, device_role)
    if hasattr(APP_CFG, "RANGING_ROUND_USAGE"):
        c_builder.add_attr(APP_CFG.RANGING_ROUND_USAGE, rng_type)
    if hasattr(APP_CFG, "STS_CONFIG"):
        c_builder.add_attr(APP_CFG.STS_CONFIG, APP_CFG.STS_CONFIG.NO_SE_STATIC_STS)
    if hasattr(APP_CFG, "MULTI_NODE_MODE"):
        c_builder.add_attr(APP_CFG.MULTI_NODE_MODE, multi_node_mode)
    if hasattr(APP_CFG, "CHANNEL_ID"):
        c_builder.add_attr(APP_CFG.CHANNEL_ID, channel)
    if hasattr(APP_CFG, "NUMBER_OF_CONTROLEES"):
        c_builder.add_attr(APP_CFG.NUMBER_OF_CONTROLEES, no_of_anchors)
    if hasattr(APP_CFG, "SRC_MAC_ADDRESS"):
        c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS, src_addr)
    if hasattr(APP_CFG, "DST_MAC_ADDRESS_LIST"):
        c_builder.add_attr(APP_CFG.DST_MAC_ADDRESS_LIST, dst_addr)
    if hasattr(APP_CFG, "SLOT_DURATION"):
        c_builder.add_attr(APP_CFG.SLOT_DURATION, APP_CFG.SLOT_DURATION.DEFAULT_RANGING)
    if hasattr(APP_CFG, "RANGING_DURATION"):
        c_builder.add_attr(APP_CFG.RANGING_DURATION, ri)
    if hasattr(APP_CFG, "STS_INDEX"):
        c_builder.add_attr(APP_CFG.STS_INDEX, APP_CFG.STS_INDEX.STS_ZERO)
    if hasattr(APP_CFG, "MAC_TYPE"):
        c_builder.add_attr(APP_CFG.MAC_TYPE, APP_CFG.MAC_TYPE.CRC_16)
    if hasattr(APP_CFG, "AOA_RESULT_REQ"):
        c_builder.add_attr(APP_CFG.AOA_RESULT_REQ, APP_CFG.AOA_RESULT_REQ.AOA_RESULT)
    if hasattr(APP_CFG, "RNG_DATA_NTF"):
        c_builder.add_attr(APP_CFG.RNG_DATA_NTF, APP_CFG.RNG_DATA_NTF.ENABLE)
    if hasattr(APP_CFG, "RNG_DATA_NTF_PROXIMITY_FAR"):
        c_builder.add_attr(APP_CFG.RNG_DATA_NTF_PROXIMITY_FAR, APP_CFG.RNG_DATA_NTF_PROXIMITY_FAR.DEFAULT_RANGING)
    if hasattr(APP_CFG, "NEAR_PROXIMITY_CONFIG"):
        c_builder.add_attr(APP_CFG.NEAR_PROXIMITY_CONFIG, APP_CFG.NEAR_PROXIMITY_CONFIG.DEFAULT)
    if hasattr(APP_CFG, "DEVICE_TYPE"):
        c_builder.add_attr(APP_CFG.DEVICE_TYPE, device_type)
    # c_builder.add_attr(APP_CFG.MAC_CFG, APP_CFG.MAC_CFG.FIRA_SESSION)  # check cpec and uci
    if hasattr(APP_CFG, "RFRAME_CONFIG"):
        c_builder.add_attr(APP_CFG.RFRAME_CONFIG, ppdu_cfg)
    if hasattr(APP_CFG, "PREAMBLE_CODE_INDEX"):
        c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX, APP_CFG.PREAMBLE_CODE_INDEX.DEFAULT)
    if hasattr(APP_CFG, "PSDU_DATA_RATE"):
        c_builder.add_attr(APP_CFG.PSDU_DATA_RATE, APP_CFG.PSDU_DATA_RATE.Mbps_6_81)
    if hasattr(APP_CFG, "PREAMBLE_DUR"):
        c_builder.add_attr(APP_CFG.PREAMBLE_DUR, APP_CFG.PREAMBLE_DUR.SYMBOLS_64)
    if hasattr(APP_CFG, "SCHEDULED_MODE"):
        c_builder.add_attr(APP_CFG.SCHEDULED_MODE, APP_CFG.SCHEDULED_MODE.TIME_SCHEDULED_RANGING)
    # if tx_antenna is not None:
    #     c_builder.add_attr(APP_CFG.ANTENNAS_CONFIGURATION_TX, tx_antenna)
    # if rx_antenna is not None:
    #     c_builder.add_attr(APP_CFG.ANTENNAS_CONFIGURATION_RX, rx_antenna)
    uci.NUM_CONFIGS = len(c_builder)
    uci.APP_TLV = c_builder.get()
    return dev.exec_uci(uci)


def set_antenna_config(dev, session_id=0x00000000, tx_antenna=None, rx_antenna=None):
    """
    UCI to set tx_antenna and rx_antenna configurations
    :param:
    tx_antenna: Tx antenna config params
    rx_antenna: Rx antenna config params
    """
    uci = get_uci(Cmds.SET_VENDOR_APP_CONFIG)
    uci.SESSION_ID = session_id
    c_builder = ConfigSetBuilder()
    # c_builder.add_attr(VENDOR_APP_CFG.ANTENNAS_CONFIGURATION_TX, tx_antenna)
    c_builder.add_attr(VENDOR_APP_CFG.ANTENNAS_CONFIGURATION_RX, rx_antenna)
    uci.NUM_CONFIGS = len(c_builder)
    uci.VENDOR_TLV = c_builder.get()
    return dev.exec_uci(uci)


def set_vendor_app_config(dev, config, value, session_id=0x00000000):
    """
    UCI to set vendor app configuration parameters
    :param:
    session_id
    config: any VENDOR_APP_CFG param
    value:
    """
    c_builder = ConfigSetBuilder()
    uci = get_uci(Cmds.SET_VENDOR_APP_CONFIG)
    uci.NUM_CONFIGS = 1
    uci.SESSION_ID = session_id
    c_builder.add_attr(config, value)
    uci.VENDOR_TLV = c_builder.get()
    return dev.exec_uci(uci)


def set_config(dev, config, value, session_id=0x00000000):
    """
    UCI to set configuration paramters
    :param:
    session_id
    config: any APP_CFG param
    value:
    """
    c_builder = ConfigSetBuilder()
    uci = get_uci(Cmds.SET_APP_CONFIG)
    uci.NUM_CONFIGS = 1
    uci.SESSION_ID = session_id
    c_builder.add_attr(config, value)
    uci.APP_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_config(dev, config, session_id=0x00000000):
    """
     UCI to get the  configurations
     :param: session_id
             onfig: any APP_CFG param
    """
    c_builder = ConfigGetBuilder()
    uci = get_uci(Cmds.GET_APP_CONFIG)
    uci.NUM_CONFIGS = 1
    uci.SESSION_ID = session_id
    uci.APP_PARAMS = c_builder.get()
    c_builder.add_attr(config)
    return dev.exec_uci(uci)

def get_vendor_config(dev, config, session_id=0x00000000):
    """
     UCI to get the  configurations
     :param: session_id
             config: any VENDOR_APP_CFG param
    """
    c_builder = ConfigGetBuilder()
    uci = get_uci(Cmds.GET_VENDOR_APP_CONFIG)
    uci.NUM_CONFIGS = 1
    uci.SESSION_ID = session_id
    uci.VENDOR_PARAMS = c_builder.get()
    c_builder.add_attr(config)
    return dev.exec_uci(uci)

def get_app_config(dev, session_id=0x00000000):
    """
    UCI to get the application parameters
    param : session_id
    """
    uci = get_uci(Cmds.GET_APP_CONFIG)
    uci.SESSION_ID = session_id
    uci.NUM_CONFIGS = 23
    c_builder = ConfigGetBuilder()
    if hasattr(APP_CFG, "DEVICE_ROLE"):
        c_builder.add_attr(APP_CFG.DEVICE_ROLE),
    if hasattr(APP_CFG, "RANGING_ROUND_USAGE"):
        c_builder.add_attr(APP_CFG.RANGING_ROUND_USAGE),
    if hasattr(APP_CFG, "STS_CONFIG"):
        c_builder.add_attr(APP_CFG.STS_CONFIG),
    if hasattr(APP_CFG, "MULTI_NODE_MODE"):
        c_builder.add_attr(APP_CFG.MULTI_NODE_MODE),
    if hasattr(APP_CFG, "CHANNEL_ID"):
        c_builder.add_attr(APP_CFG.CHANNEL_ID),
    if hasattr(APP_CFG, "NUMBER_OF_CONTROLEES"):
        c_builder.add_attr(APP_CFG.NUMBER_OF_CONTROLEES),
    if hasattr(APP_CFG, "SRC_MAC_ADDRESS"):
        c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS),
    if hasattr(APP_CFG, "DST_MAC_ADDRESS_LIST"):
        c_builder.add_attr(APP_CFG.DST_MAC_ADDRESS_LIST),
    if hasattr(APP_CFG, "SLOT_DURATION"):
        c_builder.add_attr(APP_CFG.SLOT_DURATION),
    if hasattr(APP_CFG, "RANGING_DURATION"):
        c_builder.add_attr(APP_CFG.RANGING_DURATION),
    if hasattr(APP_CFG, "STS_INDEX"):
        c_builder.add_attr(APP_CFG.STS_INDEX),
    if hasattr(APP_CFG, "MAC_TYPE"):
        c_builder.add_attr(APP_CFG.MAC_TYPE),
    if hasattr(APP_CFG, "AOA_RESULT_REQ"):
        c_builder.add_attr(APP_CFG.AOA_RESULT_REQ),
    if hasattr(APP_CFG, "RNG_DATA_NTF"):
        c_builder.add_attr(APP_CFG.RNG_DATA_NTF),
    if hasattr(APP_CFG, "RNG_DATA_NTF_PROXIMITY_FAR"):
        c_builder.add_attr(APP_CFG.RNG_DATA_NTF_PROXIMITY_FAR),
    if hasattr(APP_CFG, "NEAR_PROXIMITY_CONFIG"):
        c_builder.add_attr(APP_CFG.NEAR_PROXIMITY_CONFIG),
    if hasattr(APP_CFG, "DEVICE_TYPE"):
        c_builder.add_attr(APP_CFG.DEVICE_TYPE),
    # c_builder.add_attr(APP_CFG.MAC_CFG),
    if hasattr(APP_CFG, "RFRAME_CONFIG"):
        c_builder.add_attr(APP_CFG.RFRAME_CONFIG),
    if hasattr(APP_CFG, "PREAMBLE_CODE_INDEX"):
        c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX),
    if hasattr(APP_CFG, "SFD_ID"):
        c_builder.add_attr(APP_CFG.SFD_ID),
    if hasattr(APP_CFG, "PSDU_DATA_RATE"):
        c_builder.add_attr(APP_CFG.PSDU_DATA_RATE),
    if hasattr(APP_CFG, "PREAMBLE_DUR"):
        c_builder.add_attr(APP_CFG.PREAMBLE_DUR),
    if hasattr(APP_CFG, "SCHEDULED_MODE"):
        c_builder.add_attr(APP_CFG.SCHEDULED_MODE),
    uci.APP_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def set_channel(dev, session_id=0x00000000, channel=APP_CFG.CHANNEL_ID.CH_5):
    """
     UCI to set channel
     :param: session_id
             channel: CH_5,CH_6,CH_7,CH_8,CH_9
    """
    return set_config(dev, session_id=session_id, config=APP_CFG.CHANNEL_ID, value=channel)


def set_power_idx(dev, channel=APP_CFG.CHANNEL_ID.CH_9, pwr_idx=0x0, session_id=0x0):
    """
      UCI to set power
      :param:
        channel: 5, 6, 8, 9
        pwr_idx: 0 to 127
      """
    set_config(dev, session_id=session_id, config=APP_CFG.TX_ADAPTIVE_PAYLOAD_POWER,
               # disable rms power index per pay load
               value=APP_CFG.TX_ADAPTIVE_PAYLOAD_POWER.DISABLED)
    return set_calibration(dev, channel, CALIB_TYPE.TX_POWER_PER_ANTENNA, pwr_idx)


def get_calibration(dev, channel=APP_CFG.CHANNEL_ID.CH_9, calibParam=CALIB_TYPE.TX_POWER_PER_ANTENNA):
    """
    channel: channel for which param is applied and to be read
    calibPAram: calib param Id.
    return: calib value
    """
    uci = get_uci(Cmds.GET_DEVICE_CALIBRATION)
    uci.CHANNEL_ID = channel
    uci.CALIB_PARAM = calibParam
    return dev.exec_uci(uci)


def set_calibration(dev, channel=APP_CFG.CHANNEL_ID.CH_9, calibParam=CALIB_TYPE.TX_POWER_PER_ANTENNA, value=0):
    """
    channel: channel for which calibration to be set
    calibParam: calib param Id.
    calibvalue: calib param Id.
    return: rsp
    """
    uci = get_uci(Cmds.SET_DEVICE_CALIBRATION)
    uci.CHANNEL_ID = channel
    uci.TAG = calibParam
    if isinstance(value, int):
        ln = max((value.bit_length() + 7) // 8, 2)  # min calib value is of len 2
        value = list(value.to_bytes(ln, 'little'))
    uci.CALIBRATION_VALUE = value
    uci.LENGTH = len(uci.CALIBRATION_VALUE)
    return dev.exec_uci(uci)


def do_calibration(dev, channel=APP_CFG.CHANNEL_ID.CH_9, calibParam=CALIB_TYPE.VCO_PLL):
    """
    channel: channel for which calibration to be done
    calibPAram: calib param Id.
    return: rsp
    """
    uci = get_uci(Cmds.DO_CALIBRATION)
    uci.CHANNEL_ID = channel
    uci.CALIB_PARAM = calibParam
    return dev.exec_uci(uci)


def set_ranging_duration(dev, session_id=0x00000000, ri=APP_CFG.RANGING_DURATION.DEFAULT_RANGING):
    """  Ranging interval is time in ms between beginning of one ranging round to the beginning of the next.
    Minimum Ranging interval should be at least the duration of one ranging round length.
    :param: session_id
            ranging interval:  DEFAULT_RANGING(200ms)
    """
    return set_config(dev, session_id=session_id, config=APP_CFG.RANGING_DURATION, value=ri)


def set_ppdu_config(dev, session_id=0x00000000, ppdu=APP_CFG.RFRAME_CONFIG.SP0):
    """
    UCI to set ppdu configuration
    :param: session_id
            ppdu:NO_STS,STS_FOLLOWS_SFD,STS_FOLLOWS_PSDU,STS_FOLLOWS_SFD_NO_PPDU
    """
    return set_config(dev, session_id=session_id, config=APP_CFG.RFRAME_CONFIG, value=ppdu)


def set_sts_config(dev, session_id=0x00000000, sts=APP_CFG.STS_CONFIG.NO_SE_STATIC_STS):
    """
    This parameter indicates how system shall generate the STS.
    0= Static STS (SE not involved) (default)
    1= Dynamic STS (Session Key will be generated via SE)
    """
    return set_config(dev, session_id=session_id, config=APP_CFG.STS_CONFIG, value=sts)


def set_app_config_per(dev, session_id=0x0,
                       src_addr=APP_CFG.SRC_MAC_ADDRESS.MASTER_ADDR,
                       dst_addr=APP_CFG.DST_MAC_ADDRESS_LIST.ANCHOR_ADDR,
                       preamble_id=APP_CFG.PREAMBLE_CODE_INDEX.DEFAULT,
                       channel=APP_CFG.CHANNEL_ID.CH_9,
                       tx_antenna=None,
                       rx_antenna=None):
    """
    UCI to set application configuration to prepare device for PER test
    parma:  session_id
              src :SRC_MAC_ADDRESS
              dst :DST_MAC_ADDRESS
              preamble_id :PREAMBLE_ID.DEFAULT(18-dec)
              channel :CH_5,CH_6,CH_7,CH_8,CH_9
              power_idx :DEFAULT_MAX_POWER
    """
    uci = get_uci(Cmds.SET_APP_CONFIG)
    uci.SESSION_ID = session_id
    c_builder = ConfigSetBuilder()
    c_builder.add_attr(APP_CFG.CHANNEL_ID, channel),
    c_builder.add_attr(APP_CFG.STS_CONFIG, APP_CFG.STS_CONFIG.NO_SE_STATIC_STS),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS, src_addr),
    c_builder.add_attr(APP_CFG.DST_MAC_ADDRESS_LIST, dst_addr),
    c_builder.add_attr(APP_CFG.STS_INDEX, APP_CFG.STS_INDEX.STS_ZERO),
    c_builder.add_attr(APP_CFG.NUMBER_OF_CONTROLEES, APP_CFG.NUMBER_OF_CONTROLEES.SINGLE_ANCHOR),
    c_builder.add_attr(APP_CFG.MAC_TYPE, APP_CFG.MAC_TYPE.CRC_16),
    c_builder.add_attr(APP_CFG.MAC_CFG, APP_CFG.MAC_CFG.DEFAULT_PER),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX, preamble_id),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE, APP_CFG.PSDU_DATA_RATE.DEFAULT),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR, APP_CFG.PREAMBLE_DUR.DEFAULT)
    if tx_antenna is not None:
        c_builder.add_attr(APP_CFG.ANTENNAS_CONFIGURATION_TX, tx_antenna)
    if rx_antenna is not None:
        c_builder.add_attr(APP_CFG.ANTENNAS_CONFIGURATION_RX, rx_antenna)
    uci.NUM_CONFIGS = len(c_builder)
    uci.APP_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_app_config_per(dev):
    """
    UCI to get the per application configurations
    """
    uci = get_uci(Cmds.GET_APP_CONFIG)
    uci.SESSION_ID = 0  # for per session id is always 0
    uci.NUM_CONFIGS = 12
    c_builder = ConfigGetBuilder()
    c_builder.add_attr(APP_CFG.CHANNEL_ID),
    c_builder.add_attr(APP_CFG.STS_CONFIG),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS),
    c_builder.add_attr(APP_CFG.DST_MAC_ADDRESS_LIST),
    c_builder.add_attr(APP_CFG.STS_INDEX),
    c_builder.add_attr(APP_CFG.MAC_TYPE),
    c_builder.add_attr(APP_CFG.MAC_CFG),
    c_builder.add_attr(APP_CFG.RFRAME_CONFIG),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX),
    c_builder.add_attr(APP_CFG.SFD_ID),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR),
    uci.APP_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def set_test_config(dev, config, value, session_id=0x0):
    """
    UCI to set test onfiguration paramters
    :param:
    session_id
    config: any TEST_CFG param
    value:
    """
    c_builder = ConfigSetBuilder()
    uci = get_uci(Cmds.TEST_CONFIG_SET)
    uci.NUM_TEST_CONFIG = 1
    uci.SESSION_ID = session_id
    c_builder.add_attr(config, value)
    uci.TEST_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_test_config(dev, config):
    """
    UCI to get  test configurations.
    """
    uci = get_uci(Cmds.TEST_CONFIG_GET)
    uci.SESSION_ID = 0
    uci.NUM_TEST_CONFIG = 1
    c_builder = ConfigGetBuilder()
    c_builder.add_attr(config)
    uci.TEST_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def set_app_config_data(dev, session_id=0x1, device_type=APP_CFG.DEVICE_TYPE.CONTROLLER,
                        src_addr=APP_CFG.SRC_MAC_ADDRESS.MASTER_ADDR):
    """
       UCI to set application parameters for data transfer.
       :param: session_id
                device_type : INITIATOR,RESPONDER
                src_addr :  SRC_MAC_ADDRESS
    """
    uci = get_uci(Cmds.SET_APP_CONFIG)
    uci.SESSION_ID = session_id
    uci.NUM_CONFIGS = 12
    c_builder = ConfigSetBuilder()
    c_builder.add_attr(APP_CFG.DEVICE_TYPE, device_type),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS, src_addr),
    c_builder.add_attr(APP_CFG.CHANNEL_ID, APP_CFG.CHANNEL_ID.CH_5),
    c_builder.add_attr(APP_CFG.STS_CONFIG, APP_CFG.STS_CONFIG.NO_SE_STATIC_STS),
    c_builder.add_attr(APP_CFG.STS_INDEX, APP_CFG.STS_INDEX.STS_ZERO),
    c_builder.add_attr(APP_CFG.MAC_TYPE, APP_CFG.MAC_TYPE.CRC_16),
    c_builder.add_attr(APP_CFG.MAC_CFG, APP_CFG.MAC_CFG.FIRA_SESSION),
    c_builder.add_attr(APP_CFG.RFRAME_CONFIG, APP_CFG.RFRAME_CONFIG.SP3),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX, APP_CFG.PREAMBLE_CODE_INDEX.DEFAULT),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE, APP_CFG.PSDU_DATA_RATE.DEFAULT),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR, APP_CFG.PREAMBLE_DUR.DEFAULT),
    uci.APP_TLV = c_builder.get()
    return dev.exec_uci(uci)


def get_app_config_data(dev, session_id=0x1):
    """
     UCI to get configurations of data transfer
    :param: session_id
    """
    uci = get_uci(Cmds.GET_APP_CONFIG)
    uci.SESSION_ID = session_id
    uci.NUM_CONFIGS = 13
    c_builder = ConfigGetBuilder()
    c_builder.add_attr(APP_CFG.DEVICE_TYPE),
    c_builder.add_attr(APP_CFG.SRC_MAC_ADDRESS),
    c_builder.add_attr(APP_CFG.CHANNEL_ID),
    c_builder.add_attr(APP_CFG.STS_CONFIG),
    c_builder.add_attr(APP_CFG.STS_INDEX),
    c_builder.add_attr(APP_CFG.MAC_TYPE),
    c_builder.add_attr(APP_CFG.MAC_CFG),
    c_builder.add_attr(APP_CFG.RFRAME_CONFIG),
    c_builder.add_attr(APP_CFG.PREAMBLE_CODE_INDEX),
    c_builder.add_attr(APP_CFG.SFD_ID),
    c_builder.add_attr(APP_CFG.PSDU_DATA_RATE),
    c_builder.add_attr(APP_CFG.PREAMBLE_DUR),
    uci.APP_PARAMS = c_builder.get()
    return dev.exec_uci(uci)


def rng_start(dev, session_id=0x00000000):
    """
       UCI to start ranging
       :param: session_id
    """
    uci = get_uci(Cmds.SESSION_START)
    uci.SESSION_ID = session_id
    return dev.exec_uci(uci)


def rng_stop(dev, session_id=0x00000000):
    """
        UCI to stop ranging
        :param: session_id
    """
    uci = get_uci(Cmds.SESSION_STOP)
    uci.SESSION_ID = session_id
    return dev.exec_uci(uci)


def periodic_tx(dev, psdu_data=None):
    """
      uci to start per tx.
      Issue this after applying all required configuration and the "Device test mode" session must be in SESSION_IDLE.
      Otherwise UWBD responds with TEST_PERIODIC_TX_RSP with status
      STATUS_SESSION_NOT_CONFIGURED error indicating that session is not configured.
      param: psdu_data
     """
    if psdu_data is None:
        psdu_data = [0x1]
    uci = get_uci(Cmds.TEST_PERIODIC_TX)
    uci.PSDU_DATA = psdu_data
    return dev.exec_uci(uci)


def periodic_rx(dev, psdu_data=None):
    """
       uci to start per rx
       param: psdu_data
    """
    if psdu_data is None:
        psdu_data = [0x1]
    uci = get_uci(Cmds.TEST_PER_RX)
    uci.PSDU_DATA = psdu_data
    return dev.exec_uci(uci)


def device_init(dev, board=PLATFORM.RHODES, variant=BOARD_VARIANT.V2):
    """
       uci to set platform configs, defaults to Rhodes V2
       :param:
       board: NXP_REF,SSG,RHODES
    """
    if dev.device.uci_ready_mode:
        return
    uci = get_uci(Cmds.DEVICE_INIT)
    uci.VARIANT_ID = variant
    uci.PLATFORM_ID = board
    rsp = dev.exec_uci(uci)
    ntf = dev.wait_for_notification(ntf=Cmds.DEVICE_STATUS_NTF, timeout=2)
    retry = 1
    while ntf and ntf.fields['DEVICE_STATUS'].name != 'STATUS_READY':
        ntf = dev.wait_for_notification(ntf=Cmds.DEVICE_STATUS_NTF, timeout=2)
        if retry == 3:
            print('No device ready ntf yet, continue!')
            break
        retry += 1
    return rsp


def se_do_bind(dev):
    """
    UCI to do the binding
    """
    return dev.exec_uci(Cmds.SE_DO_BIND)


def debug_get_error_log(dev):
    """
    DBG_GET_ERROR_LOG_CMD command to fetch the error log from SR100 in STATUS_ERROR state.
    SR100 responds by DBG_GET_ERROR_LOG_RSP with error log data
    """
    return dev.exec_uci(Cmds.DBG_GET_ERROR_LOG)


def rx_test(dev):
    """
     UCI  to recieve a single rx packet
     """
    uci = get_uci(Cmds.TEST_RX)
    return dev.exec_uci(uci)


def tx_test(dev, psdu_data=None):
    """
     UCI  to send a single tx packet
     """
    if psdu_data is None:
        psdu_data = [0x1, 0x2, 0x3, 0x4]
    uci = get_uci(Cmds.TEST_TX)
    uci.PSDU_DATA = psdu_data
    return dev.exec_uci(uci)


def loopback_test(dev, psdu_data=None):
    """
     UCI  to do a device to device loopback
     """
    if psdu_data is None:
        psdu_data = [0x1, 0x2, 0x3, 0x4]
    uci = get_uci(Cmds.TEST_LOOPBACK)
    uci.PSDU_DATA = psdu_data
    return dev.exec_uci(uci)


# @__calculate_time
def device_creation(dev, fw=None, skip_fw_download=False):
    """
     Device host command to do init a device and do UWBD firmware download
    """
    assert dev and dev.device and dev.device_host != UwbDeviceCfg.DUMMY, 'Device Error'
    if not dev.device.uci_ready_mode and not skip_fw_download:
        dev.device.fw_download(fw)
    dev.device.uci_handler.start_uci_handler()


def fw_download(dev):  # noqa
    """
    This does nothing, but a place holder for fw download
    """
    pass


def parse(dev, uci):
    """
      Device host command to parse a uci data
    """
    dev.generate_uci(uci_hex_str=uci)


def get_session_state(dev, session_id=0x00000000):
    uci = get_uci(Cmds.SESSION_GET_STATE)
    uci.SESSION_ID = session_id
    return dev.exec_uci(uci)


def sstwr_test(dev):
    """Test UCI to trigger SS-TWR"""
    uci = get_uci(Cmds.TEST_SS_TWR)
    return dev.exec_uci(uci)


def send_data(dev, session_id=0x00000000, dst=APP_CFG.DST_MAC_ADDRESS_LIST.ANCHOR_ADDR, data=None):
    """
    Send a data packet
    """
    if not data:
        data = [1, 2, 3, 4]
    uci = get_uci(Cmds.DATA_PKT)
    uci.SESSION_ID = session_id
    uci.MAC_ADDR = dst
    uci.DATA = data
    return dev.send_uci(uci)


def send_data_msg(dev, session_id=0x00000000, dst=APP_CFG.DST_MAC_ADDRESS_LIST.ANCHOR_ADDR,
                  dst_end_pnt=0, seq_num=0, data=None):
    """
    Send a data packet
    """
    if not data:
        data = [1, 2, 3, 4]
    uci = get_uci(Cmds.DATA_MSG_SND)
    uci.SESSION_ID = session_id
    uci.DEST_ADDR = dst
    uci.DST_END_POINT = dst_end_pnt
    uci.SEQ_NUM = seq_num
    uci.APP_DATA_LEN = len(data)
    uci.APP_DATA = data
    return dev.send_uci(uci)


def blink_data_tx(dev, session_id=0x00000000, repeat_cnt=1, data=None):
    """
    Send a blink data
    """
    if not data:
        data = [1, 2, 3, 4]
    uci = get_uci(Cmds.BLINK_DATA_TX)
    uci.SESSION_ID = session_id
    uci.REPEAT_COUNT = repeat_cnt
    uci.APP_DATA_LEN = len(data)
    uci.APP_DATA = data
    return dev.send_uci(uci)


def session_update_active_round_anchor(dev, session_id=0x00000000, num_active_rng_rounds=1, rng_round_indexes=None):
    """
    update active round indexes for dl-tdoa for anchor
    """
    if not rng_round_indexes:
        rng_round_indexes = []
    uci = get_uci(Cmds.SESSION_UPDATE_ACTIVE_ROUND_ANCHOR)
    uci.SESSION_ID = session_id
    uci.NUM_ACTIVE_RNG_ROUNDS = num_active_rng_rounds
    uci.RNG_ROUND_INDEXES = rng_round_indexes
    return dev.exec_uci(uci)


def session_update_active_round_receiver(dev, session_id=0x00000000, num_active_rng_rounds=1, rng_round_indexes=None):
    """
    update active round indexes for dl-tdoa for mobile devices
    """
    if not rng_round_indexes:
        rng_round_indexes = []
    uci = get_uci(Cmds.SESSION_UPDATE_ACTIVE_ROUND_RECEIVER)
    uci.SESSION_ID = session_id
    uci.NUM_ACTIVE_RNG_ROUNDS = num_active_rng_rounds
    uci.RNG_ROUND_INDEXES = rng_round_indexes
    return dev.exec_uci(uci)
